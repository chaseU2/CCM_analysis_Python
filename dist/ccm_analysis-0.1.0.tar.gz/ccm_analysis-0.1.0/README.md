# CCM Analysis

A Python package for performing Convergent Cross Mapping (CCM) analysis on time series data.

## Installation

You can install the package via pip:

```bash
pip install ccm_analysis
